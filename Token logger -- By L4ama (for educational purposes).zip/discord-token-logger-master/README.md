# Discord Token Logger [and more]

##### Disclaimer - this is to spread awareness and to educate, any malicious use of this code isnt my fault and is not encouraged

###### Hopefully people learn how to check clients properly now instead of just flexing their intellect and cracking skills :)

##### this grabs the following things : 
> pc name (any os)<br />
> mc name (any os)<br />
> os name (any os)<br />
> ip (any os)<br />
> 2fa and normal tokens (mac and windows) - easily added to certain linux distros<br />
> future accounts (windows)<br />
> future waypoints (windows)<br />

creds -
https://github.com/RANKTW/Discord-Webhooks-API - for a robust webhook api (everyone else's suck)
